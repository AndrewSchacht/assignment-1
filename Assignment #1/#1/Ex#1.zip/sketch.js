function setup() {
  createCanvas(600, 300);
}

function draw() {
  background(119, 242, 59);

 
 strokeWeight(2.5);
  
    // Draw a circle
    circle(150, 150, 250);
   
    // Draw a square
    square(325, 25, 250);
}
